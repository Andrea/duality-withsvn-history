﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Duality;

namespace __Namespace__
{
	[Serializable]
    public class YourCustomComponentType : Component
    {

    }
}
