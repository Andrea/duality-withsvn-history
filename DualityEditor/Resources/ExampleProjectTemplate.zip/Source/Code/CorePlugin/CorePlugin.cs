﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Duality;

namespace ExampleTemplate
{
	/// <summary>
	/// Defines a Duality core plugin.
	/// </summary>
    public class ExampleTemplateCorePlugin : CorePlugin
    {
		// Override methods here for global logic
    }
}
