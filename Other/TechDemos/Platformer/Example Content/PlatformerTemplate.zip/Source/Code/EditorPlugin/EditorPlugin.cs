﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using DualityEditor;

namespace SomePlatformer.Editor
{
	/// <summary>
	/// Defines a Duality editor plugin.
	/// </summary>
    public class SomePlatformerEditorPlugin : EditorPlugin
	{
		public override string Id
		{
			get { return "SomePlatformerEditorPlugin"; }
		}
	}
}
