/*
 * A set of static helper classes that provide easy runtime access to the games resources.
 * This file is auto-generated. Any changes made to it are lost as soon as Duality decides
 * to regenerate it.
 */
namespace GameRes
{
	public static class Data {
		public static class Levels {
			private static Duality.ContentRef<Duality.Resources.Scene> _FirstLevel_Scene;
			public static Duality.ContentRef<Duality.Resources.Scene> FirstLevel_Scene { get { if (_FirstLevel_Scene.IsExplicitNull) _FirstLevel_Scene = Duality.ContentProvider.RequestContent<Duality.Resources.Scene>(@"Data\Levels\FirstLevel.Scene.res"); return _FirstLevel_Scene; }}
			public static void LoadAll() {
				FirstLevel_Scene.MakeAvailable();
			}
		}
		public static class Prefabs {
			private static Duality.ContentRef<Duality.Resources.Prefab> _PlayerChar_Prefab;
			public static Duality.ContentRef<Duality.Resources.Prefab> PlayerChar_Prefab { get { if (_PlayerChar_Prefab.IsExplicitNull) _PlayerChar_Prefab = Duality.ContentProvider.RequestContent<Duality.Resources.Prefab>(@"Data\Prefabs\PlayerChar.Prefab.res"); return _PlayerChar_Prefab; }}
			public static void LoadAll() {
				PlayerChar_Prefab.MakeAvailable();
			}
		}
		public static class Sprites {
			private static Duality.ContentRef<Duality.Resources.Material> _GrassBlueSkyBg_Material;
			public static Duality.ContentRef<Duality.Resources.Material> GrassBlueSkyBg_Material { get { if (_GrassBlueSkyBg_Material.IsExplicitNull) _GrassBlueSkyBg_Material = Duality.ContentProvider.RequestContent<Duality.Resources.Material>(@"Data\Sprites\GrassBlueSkyBg.Material.res"); return _GrassBlueSkyBg_Material; }}
			private static Duality.ContentRef<Duality.Resources.Pixmap> _GrassBlueSkyBg_Pixmap;
			public static Duality.ContentRef<Duality.Resources.Pixmap> GrassBlueSkyBg_Pixmap { get { if (_GrassBlueSkyBg_Pixmap.IsExplicitNull) _GrassBlueSkyBg_Pixmap = Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\Sprites\GrassBlueSkyBg.Pixmap.res"); return _GrassBlueSkyBg_Pixmap; }}
			private static Duality.ContentRef<Duality.Resources.Texture> _GrassBlueSkyBg_Texture;
			public static Duality.ContentRef<Duality.Resources.Texture> GrassBlueSkyBg_Texture { get { if (_GrassBlueSkyBg_Texture.IsExplicitNull) _GrassBlueSkyBg_Texture = Duality.ContentProvider.RequestContent<Duality.Resources.Texture>(@"Data\Sprites\GrassBlueSkyBg.Texture.res"); return _GrassBlueSkyBg_Texture; }}
			private static Duality.ContentRef<Duality.Resources.Material> _PlayerChar_Material;
			public static Duality.ContentRef<Duality.Resources.Material> PlayerChar_Material { get { if (_PlayerChar_Material.IsExplicitNull) _PlayerChar_Material = Duality.ContentProvider.RequestContent<Duality.Resources.Material>(@"Data\Sprites\PlayerChar.Material.res"); return _PlayerChar_Material; }}
			private static Duality.ContentRef<Duality.Resources.Pixmap> _PlayerChar_Pixmap;
			public static Duality.ContentRef<Duality.Resources.Pixmap> PlayerChar_Pixmap { get { if (_PlayerChar_Pixmap.IsExplicitNull) _PlayerChar_Pixmap = Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\Sprites\PlayerChar.Pixmap.res"); return _PlayerChar_Pixmap; }}
			private static Duality.ContentRef<Duality.Resources.Texture> _PlayerChar_Texture;
			public static Duality.ContentRef<Duality.Resources.Texture> PlayerChar_Texture { get { if (_PlayerChar_Texture.IsExplicitNull) _PlayerChar_Texture = Duality.ContentProvider.RequestContent<Duality.Resources.Texture>(@"Data\Sprites\PlayerChar.Texture.res"); return _PlayerChar_Texture; }}
			private static Duality.ContentRef<Duality.Resources.Material> _SomeLandscape_Material;
			public static Duality.ContentRef<Duality.Resources.Material> SomeLandscape_Material { get { if (_SomeLandscape_Material.IsExplicitNull) _SomeLandscape_Material = Duality.ContentProvider.RequestContent<Duality.Resources.Material>(@"Data\Sprites\SomeLandscape.Material.res"); return _SomeLandscape_Material; }}
			private static Duality.ContentRef<Duality.Resources.Pixmap> _SomeLandscape_Pixmap;
			public static Duality.ContentRef<Duality.Resources.Pixmap> SomeLandscape_Pixmap { get { if (_SomeLandscape_Pixmap.IsExplicitNull) _SomeLandscape_Pixmap = Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\Sprites\SomeLandscape.Pixmap.res"); return _SomeLandscape_Pixmap; }}
			private static Duality.ContentRef<Duality.Resources.Texture> _SomeLandscape_Texture;
			public static Duality.ContentRef<Duality.Resources.Texture> SomeLandscape_Texture { get { if (_SomeLandscape_Texture.IsExplicitNull) _SomeLandscape_Texture = Duality.ContentProvider.RequestContent<Duality.Resources.Texture>(@"Data\Sprites\SomeLandscape.Texture.res"); return _SomeLandscape_Texture; }}
			public static void LoadAll() {
				GrassBlueSkyBg_Material.MakeAvailable();
				GrassBlueSkyBg_Pixmap.MakeAvailable();
				GrassBlueSkyBg_Texture.MakeAvailable();
				PlayerChar_Material.MakeAvailable();
				PlayerChar_Pixmap.MakeAvailable();
				PlayerChar_Texture.MakeAvailable();
				SomeLandscape_Material.MakeAvailable();
				SomeLandscape_Pixmap.MakeAvailable();
				SomeLandscape_Texture.MakeAvailable();
			}
		}
		public static void LoadAll() {
			Levels.LoadAll();
			Prefabs.LoadAll();
			Sprites.LoadAll();
		}
	}

}
