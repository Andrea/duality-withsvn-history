﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Duality;
using Duality.Components;
using Duality.Components.Physics;
using Duality.Components.Renderers;

using OpenTK;
using OpenTK.Input;

namespace SomePlatformer
{
	[Serializable]
	[RequiredComponent(typeof(RigidBody))]
	[RequiredComponent(typeof(AnimSpriteRenderer))]
    public class CharacterController : Component, ICmpUpdatable, ICmpInitializable, ICmpCollisionListener
    {
		private	int	sensorContactCount	= 0;

		public bool IsOnGround
		{
			get { return this.sensorContactCount > 0; }
		}

		void ICmpUpdatable.OnUpdate()
		{
			RigidBody body = this.GameObj.RigidBody;
			AnimSpriteRenderer sprite = this.GameObj.GetComponent<AnimSpriteRenderer>();
			RevoluteJointInfo motor = body.Joints.OfType<RevoluteJointInfo>().FirstOrDefault();

			if (DualityApp.Keyboard[Key.Left])
			{
				motor.MotorSpeed = -0.5f;
				sprite.AnimFirstFrame = 9;
				sprite.AnimLoopMode = AnimSpriteRenderer.LoopMode.Loop;
			}
			else if (DualityApp.Keyboard[Key.Right])
			{
				motor.MotorSpeed = 0.5f;
				sprite.AnimFirstFrame = 3;
				sprite.AnimLoopMode = AnimSpriteRenderer.LoopMode.Loop;
			}
			else
			{
				motor.MotorSpeed = 0.0f;
				sprite.AnimFirstFrame = 6;
				sprite.AnimLoopMode = AnimSpriteRenderer.LoopMode.FixedSingle;
				sprite.AnimTime = 0.0f;
			}
		}

		void ICmpInitializable.OnInit(Component.InitContext context)
		{
			if (context == InitContext.Activate)
			{
				DualityApp.Keyboard.KeyDown += this.Keyboard_KeyDown;
			}
		}
		void ICmpInitializable.OnShutdown(Component.ShutdownContext context)
		{
			if (context == ShutdownContext.Deactivate)
			{
				DualityApp.Keyboard.KeyDown -= this.Keyboard_KeyDown;
			}
		}

		void ICmpCollisionListener.OnCollisionBegin(Component sender, CollisionEventArgs args)
		{
			RigidBodyCollisionEventArgs bodyCollision = args as RigidBodyCollisionEventArgs;
			if (bodyCollision == null) return;

			if (bodyCollision.MyShape.IsSensor)
				this.sensorContactCount++;
		}
		void ICmpCollisionListener.OnCollisionEnd(Component sender, CollisionEventArgs args)
		{
			RigidBodyCollisionEventArgs bodyCollision = args as RigidBodyCollisionEventArgs;
			if (bodyCollision == null) return;

			if (bodyCollision.MyShape.IsSensor)
				this.sensorContactCount--;
		}
		void ICmpCollisionListener.OnCollisionSolve(Component sender, CollisionEventArgs args) {}

		private void Keyboard_KeyDown(object sender, KeyboardKeyEventArgs e)
		{
			if (e.Key == Key.Space && this.IsOnGround)
			{
				this.GameObj.RigidBody.ApplyWorldImpulse(-Vector2.UnitY * 0.45f);
			}
		}
	}
}
